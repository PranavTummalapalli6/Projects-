//
//  SplashScreenView.swift
//  PokerChipApp
//
//  Created by Pranav on 4/2/25.
//

import SwiftUI

struct SplashScreenView: View {
    @State private var showAuthentication = false

    var body: some View {
        Group {
            if showAuthentication {
                AuthenticationView()
            } else {
                VStack {
                    Image("ChatGPT Image Mar 31, 2025 at 05_12_52 AM")
                        .resizable()
                        .scaledToFit()
                        .padding(40)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black)
                .ignoresSafeArea()
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.6) {
                        withAnimation {
                            showAuthentication = true
                        }
                    }
                }
            }
        }
    }
}

struct SplashScreenView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView()
    }
}

